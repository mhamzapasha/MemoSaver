package com.example.muhammad_hamza.memosaver;

/**
 * Created by Muhammad_Hamza on 26-Jan-18.
 */

public class User_setter_getter {

    String name, pswd;
    String memo;


    public void setName (String name){
        this.name=name;
    }

    public String getName(){
        return this.name;
    }

    public void setPswd (String pswd){
        this.pswd = pswd;
    }

    public String getPswd(){
        return this.pswd;
    }

    public void setMemo(String memo){
        this.memo = memo;
    }

    public String getMemo(){
        return this.memo;
    }

}
