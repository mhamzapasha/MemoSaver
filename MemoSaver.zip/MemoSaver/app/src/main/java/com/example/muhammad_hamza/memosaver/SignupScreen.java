package com.example.muhammad_hamza.memosaver;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.security.PublicKey;

public class SignupScreen extends AppCompatActivity {

    MemoDATABASE memo_db = new MemoDATABASE(this);

    public EditText signup_et_username = (EditText)findViewById(R.id.signup_userName);
    public String et_UN = signup_et_username.getText().toString();

    public EditText signup_et_pswd = (EditText)findViewById(R.id.signup_pswd);
    public String et_pass = signup_et_pswd.getText().toString();

    public EditText signup_et_confirm_pswd = (EditText)findViewById(R.id.signup_confirm_pswd);
    public String et_cnfrm_pswd = signup_et_confirm_pswd.getText().toString();

    Button signup_back_btn = (Button)findViewById(R.id.back_submit);
    Button submit_signup_btn = (Button)findViewById(R.id.signup_submit);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_screen);

        signup_back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home_signup_intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(home_signup_intent);
            }
        });

    }

    private void signup_Button(){


        if(validate_signup()){

            //looking for validate signup
            if((et_pass == et_cnfrm_pswd) && (et_UN !=null)) {

                String s = et_UN;



                User_setter_getter user_set_get = new User_setter_getter();
                user_set_get.setName(et_UN);
                user_set_get.setPswd(et_pass);

                memo_db.createUser(user_set_get);

                Intent memo_screen = new Intent(SignupScreen.this, MemoScreen.class);
                memo_screen.putExtra("userName",s);
                startActivity(memo_screen);

            }


        }
        else{
            Toast.makeText(SignupScreen.this, "Invalid Entries", Toast.LENGTH_LONG).show();
        }
    }

    public boolean validate_signup(){


        if( et_UN == null && et_pass == null && et_cnfrm_pswd== null ){
            return false;
        }else{
            return true;
        }
    }


}
