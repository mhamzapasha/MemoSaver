package com.example.muhammad_hamza.memosaver;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Muhammad_Hamza on 26-Jan-18.
 */

public class MemoDATABASE extends SQLiteOpenHelper {



    private static final String DATABASE_NAME = "UserMemo.db";
    private static final String TABLE_NAME = "Memo_table";
    private static final String COL_ID = "ID";
    private static final String COL_NAME = "NAME";
    private static final String COL_PSWD = "PASSWORD";
    private static final String COL_MEMO = "MEMO";

    private static final String TABLE_CREATE = "create table (ID INTEGER PRIMARY KEY NOT NULL AUTOINCREMENT , " + "NAME TEXT NOT NULL , PASSWORD TEXT NOT NULL , MEMO TEXT NOT NULL);";


    public MemoDATABASE(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    public MemoDATABASE md;
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.md = md;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        String upgrade_query = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(upgrade_query);
        onCreate(db);
    }

    public void createUser(User_setter_getter usg){

        SQLiteDatabase md1 = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        String qu = "Select * from " + TABLE_NAME;
        Cursor cur = md1.rawQuery(qu, null);
        int count = cur.getCount();
        cv.put(COL_ID, count);
        cv.put(COL_NAME, usg.getName());
        cv.put(COL_PSWD, usg.getPswd());
        cv.put(COL_MEMO, usg.getMemo());

        md1.insert(TABLE_NAME, null ,cv);
        md1.close();
    }

    public void insertMemo(User_setter_getter usgg, String i){
        SQLiteDatabase md4 = this.getWritableDatabase();
        // final String integer_ID = Integer.toString(i);
        ContentValues cont = new ContentValues();
        cont.put(COL_MEMO , usgg.getMemo());
        md4.update(TABLE_NAME,cont,"id = ?", new String[]{i});

    }


    public String searchPass(String uName){

        SQLiteDatabase md2 = this.getReadableDatabase();
        String q = "SELECT NAME, PASS FROM " + TABLE_NAME;
        Cursor cu = md2.rawQuery(q,null);
        String a ,b = "not found";
        if(cu.moveToFirst()){
            do {
                a = cu.getString(0);

                if(a.equals(uName)){


                    b = cu.getString(1);
                    break;
                }
            }while (cu.moveToNext());
        }
        return b;
    }

    public int searchID(String uName){

        SQLiteDatabase md5 =this.getReadableDatabase();
        String q = "SELECT ID FROM " + TABLE_NAME;
        Cursor cu = md5.rawQuery(q,null);
        String a;
        int b = -1;
        if(cu.moveToFirst()){
            do {
                a = cu.getString(0);

                if(a.equals(uName)){


                    b = cu.getInt(1);
                    break;
                }
            }while (cu.moveToNext());
        }
        return b;
    }

    public String searchUser (String pass){
        SQLiteDatabase md3 = this.getReadableDatabase();
        String q = "SELECT NAME, PASS FROM " + TABLE_NAME;
        Cursor cu = md3.rawQuery(q,null);
        String a = "not found",b;
        if(cu.moveToFirst()){
            do {
                b = cu.getString(1);
                if(a.equals(pass)){
                    a = cu.getString(0);

                    break;
                }
            }while (cu.moveToNext());
        }
        return a;
    }


}

    /*
    public boolean addMemo(String name_coming, String pswd_coming, String memo_coming){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NAME, name_coming);
        cv.put(COL_PSWD, pswd_coming);
        cv.put(COL_MEMO, memo_coming);

        long insertion = db.insert(TABLE_NAME, null, cv);

        if(insertion == -1){

            return true;
        }
        else {
            return false;
        }

    }

    */
