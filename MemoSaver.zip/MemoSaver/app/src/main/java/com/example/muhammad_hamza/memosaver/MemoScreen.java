package com.example.muhammad_hamza.memosaver;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MemoScreen extends AppCompatActivity {

    public TextView memo_tv = (TextView)findViewById(R.id.memo_screen_textView);

    MemoDATABASE memodb;

    Button memo_cancel_btn = (Button)findViewById(R.id.memo_cancel);
    Button memo_save_btn = (Button)findViewById(R.id.save_memo);
    EditText memo_et = (EditText)findViewById(R.id.memo_text);
    String usNa = getIntent().getStringExtra("userName");

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo_screen);

        memo_tv.setText("Welcom " + usNa);


        memo_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MemoScreen.this,MainActivity.class);
            }
        });

        memo_save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mt = memo_et.getText().toString();
                int u = memodb.searchID(usNa);


                if(u == -1){
                    Toast.makeText(MemoScreen.this, "User ID not found", Toast.LENGTH_LONG).show();
                }
                else {

                    User_setter_getter usg = new User_setter_getter();
                    usg.setMemo(mt);

                    memodb.insertMemo(usg,u);
                }

            }
        });

    }






}
