package com.example.muhammad_hamza.memosaver;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SigninScreen extends AppCompatActivity {

    MemoDATABASE memodb = new MemoDATABASE(this);

    public Button sign_back_btn = (Button)findViewById(R.id.back_signin);
    public Button sign_submit_btn = (Button)findViewById(R.id.submit_signin);

    public EditText login_userName = (EditText)findViewById(R.id.login_userName);
    public EditText login_pswd = (EditText)findViewById(R.id.login_pswd);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin_screen);


    }


    private void signin_back_btn(){
        sign_back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home_login_intent = new Intent(SigninScreen.this, MainActivity.class);
                startActivity(home_login_intent);

            }
        });

    }

    private void signin_login_btn(){

        sign_submit_btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                String login_et_userName = login_userName.getText().toString();
                String login_et_pswd = login_pswd.getText().toString();

                if(validate_logins()) {

                    String u = memodb.searchUser(login_et_userName);
                    String p = memodb.searchPass(login_et_pswd);
                    if(login_et_pswd.equals(p) && (login_et_userName.equals(u))){

                        String s = u;

                        Intent memo_screen = new Intent(SigninScreen.this, MemoScreen.class);
                        memo_screen.putExtra("userName",s);
                        startActivity(memo_screen);

                    }
                    else {
                        Toast.makeText(SigninScreen.this, "Password not found", Toast.LENGTH_LONG).show();
                    }






                }
                else{
                    Toast.makeText(SigninScreen.this, "Enter Valid User Name or Passwrd", Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    private boolean validate_logins(){

        if(login_userName.getText().toString() == null && login_pswd.getText().toString() == null){
            return false;
        }
        else{
            return true;
        }
    }



}
